#include "Unit.h"
#include "Boxes.h"
#include "Container.h"
#include "Event.h"
#include "simulator.h"
#include <unordered_map>
#include <array>

#ifndef Environment_h
#define Environment_h
using std::priority_queue;
class Environment {
private:
	priority_queue<Event, vector<Event>, myEventComparator> m_event_queue;

	LARGE_INTEGER m_freq;
	bool useQPC = QueryPerformanceFrequency(&m_freq);
	long long m_loop_start_time;
	long long m_loop_end_time;
	long long m_curr_loop_time;

	std::array<Unit, global_num_units> m_unitArray;
	int m_camera[3];
	int m_look[3];
	int m_view;
	Boxes m_grid;

public:

	Environment();

	void update_loop_time();

	void process();

	inline LARGE_INTEGER get_freq() {
		return m_freq;
	};

	//add unit to array of units
	void add_unit(int unitID);

	//get unit object from id
	inline Unit& get_unit(int id) {
		return m_unitArray[id];
	};


	~Environment();
	inline int* get_camera() {
		return m_camera;
	};
	inline int* get_look() {
		return m_look;
	};

	inline long long get_num_milliseconds() {
		LARGE_INTEGER now;
		QueryPerformanceCounter(&now);
		//total runtime in milliseconds
		bool useQPC = QueryPerformanceFrequency(&m_freq);
		return ((1000LL * now.QuadPart) / m_freq.QuadPart);
	};
	void change_view();
	void draw_unit(int);
	void test_send(int, int);
	std::vector<int> get_box_neighbors(int);
};

#endif /*Message_h*/