//includes for r-tree
#include <cmath>
#include <iostream>
#include <boost/geometry.hpp>
#include <boost/geometry/geometries/point.hpp>
#include <boost/geometry/geometries/box.hpp>
#include <boost/geometry/index/rtree.hpp>
#include <boost/foreach.hpp>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <utility>
#include <functional>
#include <strstream>
#include <boost/variant/get.hpp>

#ifndef Container_h
#define Container_h
class Container {
private:
	//boundaries
	int m_size;
	int m_rightX;
	int m_leftX;
	int m_topY;
	int m_bottomY;
	int m_closeZ;
	int m_farZ;

public:
	Container();

	~Container();

	inline int get_rightX() {
		return m_rightX;
	};

	inline int get_leftX() {
		return m_leftX;
	};

	inline int get_bottomY() {
		return m_bottomY;
	};

	inline int get_topY() {
		return m_topY;
	};

	inline int get_closeZ() {
		return m_closeZ;
	};

	inline int get_farZ() {
		return m_farZ;
	};

	inline int get_size() {
		return m_size;
	};

	void draw_container();

};
#endif /* Container_h */