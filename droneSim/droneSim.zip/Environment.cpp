#include "Environment.h"
#include "Unit.h"
#include "simulator.h"
#include "Boxes.h"
#include <vector>

//for drawing
#  include <GL/glew.h>
#  include <GL/freeglut.h>

#include <cmath>
#include <algorithm>
#include <iostream>
#include <boost/geometry.hpp>
#include <boost/geometry/geometries/point.hpp>
#include <boost/geometry/geometries/box.hpp>
#include <boost/geometry/index/rtree.hpp>
#include <boost/foreach.hpp>
#include <cstdio>
#include <cstdlib>
#include <stdlib.h> 
#include <array>

using std::min;

//extern constexpr float default_radius = 0.25;

Environment::Environment()
{
	//initialize camera and view
	m_camera[0] = 0;
	m_camera[1] = 0;
	int cameraZ = globalContainer.get_size();
	cameraZ = cameraZ + globalContainer.get_size();
	m_camera[2] = globalContainer.get_closeZ() + globalContainer.get_size();

	m_look[0] = 0;
	m_look[1] = 0;
	m_look[2] = -10 - globalContainer.get_size() / 2;
	m_view = 1;
	m_grid = Boxes();
}

void Environment::update_loop_time() {
	LARGE_INTEGER now;
	QueryPerformanceCounter(&now);
	//total runtime in milliseconds
	long long ms_now = ((1000LL * now.QuadPart) / m_freq.QuadPart);
	m_curr_loop_time = ms_now - m_loop_start_time;
	m_loop_start_time = ms_now;
}


void Environment::process() {
	long long total_time_left = m_curr_loop_time;
	long long currTime = get_num_milliseconds();

	if(m_event_queue.size()>0){
		Event currEvent = m_event_queue.top();
		while (currEvent.timestamp <= currTime) {
			int offset = currTime - currEvent.timestamp;
			if (currEvent.tag == 1) { //unit collision event
				Event actionEvent = m_unitArray[currEvent.idA].perform_unit_collision(m_unitArray[currEvent.idB]);
				m_event_queue.emplace(actionEvent);
			}
			if (currEvent.tag == 0) { //box transition event
				//update box membership

				m_grid.getBox(m_unitArray[currEvent.idA]);
				//add next box transition event
				m_event_queue.emplace(m_grid.get_next_box_event(m_unitArray[currEvent.idA]));
				vector<Event> collisions = m_grid.get_collisions(m_unitArray[currEvent.idA]);
				for (Event collision : collisions) {
					m_event_queue.emplace(collision);
				}
			}
			if (currEvent.tag == 2) {

			}
			for (int i = 0; i < global_num_units; i++) {
				m_unitArray[i].process(offset);
			}
			total_time_left -= offset;
			m_event_queue.pop();
			currEvent = m_event_queue.top();
		}
	}
	for (int i = 0; i < global_num_units; i++) {
		m_unitArray[i].process(total_time_left);
		draw_unit(m_unitArray[i].get_id());
		Box myBox = m_grid.getBox(m_unitArray[i].get_id());
		for (int coord : myBox.positions) {
			if (coord == 0 || coord == 9) { //must use boxes' m_boxes_per_side
				m_unitArray[i].check_container_collision();
			}
		}
	}
}

std::vector<int> Environment::get_box_neighbors(int unitID) {
	Unit unit = m_unitArray[unitID];
	return m_grid.getUnitsInBox(unit);
}

void Environment::add_unit(int unitID) {
	if (unitID == 0) { //beginning of new loop
		LARGE_INTEGER now;
		QueryPerformanceCounter(&now);
		//update loop start time
		m_loop_start_time = ((1000LL * now.QuadPart) / m_freq.QuadPart);
	}
	m_unitArray[unitID] = Unit(unitID);
	Unit newUnit = m_unitArray[unitID];

	if (unitID == 0) {
		m_unitArray[0].set_location(-5, 0, -12);
		m_unitArray[0].change_direction(1, 0, 0);
	}
	if (unitID == 1) {
		m_unitArray[1].set_location(5, 1, -12);
		m_unitArray[1].change_direction(-1, 0, 0);
	}

	Box unitBox = m_grid.getBox(m_unitArray[unitID]);
	m_grid.getBox(m_unitArray[unitID]);
	
	//get and add first box transition event
	Event firstBoxEvent = m_grid.get_next_box_event(m_unitArray[unitID]);
	m_event_queue.emplace(firstBoxEvent);

	//get and add any unit collisions
	vector<Event> collisions = m_grid.get_collisions(m_unitArray[unitID]);
	for (Event collision : collisions) {
		m_event_queue.emplace(collision);
	}

	if (unitID == global_num_units - 1) {
		LARGE_INTEGER now;
		QueryPerformanceCounter(&now);
		m_loop_end_time = ((1000LL * now.QuadPart) / m_freq.QuadPart);
		m_curr_loop_time = m_loop_end_time - m_loop_start_time;
	}
};

void Environment::draw_unit(int id) {
	glPopMatrix();
	glTranslatef(m_look[0], m_look[0], m_look[0]);

	//get unit color, radius, location
	Unit currUnit = m_unitArray[id];
	float unit_color_red = (currUnit.get_color())[0];
	float unit_color_green = (currUnit.get_color())[1];
	float unit_color_blue = (currUnit.get_color())[2];
	glColor3f(unit_color_red, unit_color_green, unit_color_blue);
	float radius = currUnit.get_radius();
	float bufferRadius = currUnit.get_bufferRadius();

	float* location = currUnit.get_location();

	//draw unit
	glPushMatrix();
	glTranslatef(*(location), *(location + 1), *(location + 2));
	//inside
	glutSolidSphere(radius, 10, 10);
	//outside
	glColor3f((float) 0.35, (float) 0.35, (float) 0.35);
	glutWireSphere(bufferRadius, 8, 5);
	glPopMatrix();
}

void Environment::change_view() {
	if (m_view == 3) {
		m_view = 1;
	}
	else {
		m_view++;
	}
	if (m_view == 1) {
		m_camera[0] = 0;
		m_camera[1] = 0;
		m_camera[2] = globalContainer.get_closeZ() + globalContainer.get_size();
	}
	else if (m_view == 2) {
		m_camera[0] = globalContainer.get_rightX() + globalContainer.get_size() / 3;
		m_camera[1] = globalContainer.get_topY() + globalContainer.get_size() / 3;
		m_camera[2] = globalContainer.get_closeZ() + globalContainer.get_size();
	}
	else if (m_view == 3) {
		m_camera[0] = 0;
		m_camera[1] = globalContainer.get_topY() + globalContainer.get_size();
		m_camera[2] = -globalContainer.get_size() / 2;
	}
}

//messaging
void Environment::test_send(int id1, int id2) {
	int number = 5;
	void* content = &number;
	Message newMessage = Message(0, id1, 0, content);
	m_unitArray[id1].send(newMessage, id2);
}

Environment::~Environment()
{
}