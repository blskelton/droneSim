
#ifndef Message_h
#define Message_h
class Message {
private:
	int m_tag;
	int m_unitID;
	int m_round;
	void* m_content;

public:
	//message constructor
	Message(int, int, int, void*);

	//default constructor (empty)
	Message();

	//returns msg tag
	inline int get_tag() {
		return m_tag;
	};

	//returns msg sender
	inline int get_sender() {
		return m_unitID;
	};
	~Message();

};

#endif /*Message_h */