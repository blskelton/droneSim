#include "Container.h"
#include "simulator.h"
#include "Environment.h"
#include <vector>
#include <cmath>
#include <sstream>
#include <string>
#include <utility>
#include <functional>

//for drawing
#  include <GL/glew.h>
#  include <GL/freeglut.h>


constexpr int  global_container_size = 20;

Container::Container() {
	m_size = global_container_size;
	m_leftX = -(m_size / 2);
	m_rightX = (m_size / 2);
	m_bottomY = -(m_size / 2);
	m_topY = (m_size / 2);
	m_closeZ = -10;
	m_farZ = m_closeZ - m_size;
}


void Container::draw_container() {
	glPushMatrix();
	glColor3f(1.0, 1.0, 0.0);
	glTranslatef(globalEnvironment.get_look()[0], globalEnvironment.get_look()[1], globalEnvironment.get_look()[2]);
	glutWireCube(m_size);
	glPopMatrix();
	//X axis
	glBegin(GL_LINES);
	glVertex3f(m_leftX, 0.0, -10 - m_size / 2);
	glVertex3f(m_rightX, 0.0, -10 - m_size / 2);
	glEnd();

	//Y axis
	glBegin(GL_LINES);
	glVertex3f(0.0, m_topY, -10 - m_size / 2);
	glVertex3f(0.0, m_bottomY, -10 - m_size / 2);
	glEnd();

	//X axis
	glBegin(GL_LINES);
	glVertex3f(0.0, 0.0, m_closeZ);
	glVertex3f(0.0, 0.0, m_farZ);
	glEnd();
}


Container::~Container()
{
}
