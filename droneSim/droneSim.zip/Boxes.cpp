#include "Boxes.h"
#include "simulator.h"
#include "Container.h"
#include "Unit.h"
#include "Event.h"
#include <vector>
#include <cmath>
#include <sstream>
#include <string>
#include <utility>
#include <functional>
#include <math.h>

class Environment;
Boxes::Boxes() {
	int containerSize = globalContainer.get_size();

	int leftX = globalContainer.get_leftX();
	int bottomY = globalContainer.get_bottomY();
	int farZ = globalContainer.get_farZ();
	int rightX = globalContainer.get_rightX();
	int topY = globalContainer.get_topY();
	int closeZ = globalContainer.get_closeZ();

	for (int i = 0; i < m_boxes_per_side[cX]; i++) {
		for (int j = 0; j < m_boxes_per_side[cY]; j++) {
			for (int k = 0; k < m_boxes_per_side[cZ]; k++) {
				Plane right = {cX, (float) leftX+(i+1)*m_box_size[cX]};
				Plane left = { cX, (float) leftX + i*m_box_size[cX]};
				Plane top = { cY, (float) bottomY + (j+1) * m_box_size[cY]};
				Plane bottom = { cY, (float) bottomY + j* m_box_size[cY]};
				Plane nearPlane = { cZ, (float) farZ + (k + 1) * m_box_size[cZ]};
				Plane farPlane = { cZ, (float) farZ + k * m_box_size[cZ]};
				m_planes[i][j][k][cX] = { right, left };
				m_planes[i][j][k][cY] = { top, bottom };
				m_planes[i][j][k][cZ] = { nearPlane, farPlane };
				for (int a = 0; a < global_num_units; a++) {
					m_unit_membership[i][j][k][a] = false;
				}
				
			}
		}
	}
}

//returns a vector of all 8 boxes (including current box) in the path of the given unit
vector<Box> Boxes::get_future_boxes(Unit unit) {
	vector<Box> boxes;

	Box myBox = getBox(unit);
	int xIndex = myBox.positions[cX];
	int yIndex = myBox.positions[cY];
	int zIndex = myBox.positions[cZ];
	
	int xDir = -1;
	int yDir = -1;
	int zDir = -1;

	if (unit.get_direction()[cX] >= 0) {
		xDir = 1;
	}
	if (unit.get_direction()[cY] >= 0) {
		yDir = 1;
	}
	if (unit.get_direction()[cZ] >= 0) {
		zDir = 1;
	}

	if (xIndex == 0 || xIndex == m_boxes_per_side[cX] - 1) {
		xDir = 0;
	}
	if (yIndex == 0 || yIndex == m_boxes_per_side[cY] - 1) {
		yDir = 0;
	}
	if (zIndex == 0 || zIndex == m_boxes_per_side[cZ] - 1) {
		zDir = 0;
	}

	Box box1 = { xIndex, yIndex, zIndex};
	Box box2 = { xIndex + xDir, yIndex, zIndex };
	Box box3 = { xIndex + xDir, yIndex + yDir, zIndex };
	Box box4 = { xIndex + xDir, yIndex, zIndex + zDir };
	Box box5 = { xIndex + xDir, yIndex + yDir, zIndex +zDir};
	Box box6 = { xIndex, yIndex + yDir, zIndex};
	Box box7 = { xIndex, yIndex + yDir, zIndex + zDir};
	Box box8 = { xIndex, yIndex, zIndex + zDir};
	boxes.emplace_back(box1);
	boxes.emplace_back(box2);
	boxes.emplace_back(box3);
	boxes.emplace_back(box4);
	boxes.emplace_back(box5);
	boxes.emplace_back(box6);
	boxes.emplace_back(box7);
	boxes.emplace_back(box8);
	return boxes;
}

//returns a vector of collision events involving the given unit
vector<Event> Boxes::get_collisions(Unit unit) {
	//get IDs of all eligible units
	vector<Box> boxes = get_future_boxes(unit);
	vector<int> neighbors;
	for (Box box : boxes) {
		vector<int> boxNeighbors = getUnitsInBox(box);
		for (int id : boxNeighbors) {
			neighbors.emplace_back(id);
		}
	}
	vector<Event> eventVector;
	//for each valid collision time, create event
	for (int id : neighbors) {
		if (id != unit.get_id()) {
			long long collisionTime = unit.unit_collision(id);
			if (collisionTime > 0) {
				Event collisionEvent = {1, unit.get_id(), id, collisionTime };
				eventVector.emplace_back(collisionEvent);
			}
		}
	}
	return eventVector;
}

//returns time in milliseconds until the given unit hits the given plane
float Boxes::time_to_plane(Unit unit, Plane plane) {
	//find required vectors
	myVector planeNormal{};
	myVector planePoint{};
	get_plane_info(plane, planeNormal, planePoint);
	myVector directionVec = { unit.get_direction()[cX], unit.get_direction()[cY],  unit.get_direction()[cZ] };
	myVector location = { unit.get_location()[cX], unit.get_location()[cY], unit.get_location()[cZ] };
	myVector dirNormalized = directionVec.normalize();

	//if unit is traveling parallel to given plane
	if (planeNormal.dot_product(dirNormalized) == 0) {
		return std::numeric_limits<float>::infinity();
	}

	float t = (planeNormal.dot_product(planePoint)-planeNormal.dot_product(location)) / (planeNormal.dot_product(dirNormalized));

	myVector intersection = location.add(dirNormalized.scalar_mult(t));

	float time = t / unit.get_speed();

	return time;
	
}


void Boxes::get_plane_info(Plane plane, myVector &normal, myVector &point) {
	if (plane.coordinate == cX) {
		normal.vals[cX] = 1;
		normal.vals[cY] = 0;
		normal.vals[cZ] = 0;
		point = { plane.offset, 0, 0 };
	}
	if (plane.coordinate == cY) {
		normal.vals[cX] = 0;
		normal.vals[cY] = 1;
		normal.vals[cZ] = 0;
		point = { 0, plane.offset, 0 };
	}
	if (plane.coordinate == cZ) {
		normal.vals[cX] = 0;
		normal.vals[cY] = 0;
		normal.vals[cZ] = 1;
		point = { 0, 0, plane.offset};
	}
}


Event Boxes::get_next_box_event(Unit unit) {
	int unitID = unit.get_id();

	//from unit, get 3 candidate planes
	Box prevBox = getBox(unit);
	std::array<Plane, 2> xPlanes = m_planes[prevBox.positions[cX]][prevBox.positions[cY]][prevBox.positions[cZ]][cX];
	std::array<Plane, 2> yPlanes = m_planes[prevBox.positions[cX]][prevBox.positions[cY]][prevBox.positions[cZ]][cY];
	std::array<Plane, 2> zPlanes = m_planes[prevBox.positions[cX]][prevBox.positions[cY]][prevBox.positions[cZ]][cZ];

	float min = INFINITY;
	//eliminate planes in opposite direction
	if (unit.get_direction()[cX] >= 0) {
		Plane currPlane = xPlanes[0];
		float time = time_to_plane(unit, currPlane);
		if (time < min) {
			min = time;
		}
	}
	if (unit.get_direction()[cX] < 0) {
		Plane currPlane = xPlanes[1];
		float time = time_to_plane(unit, currPlane);
		if (time < min) {
			min = time;
		}
	}
	if (unit.get_direction()[cY] >= 0) {
		Plane currPlane = yPlanes[0];
		float time = time_to_plane(unit, currPlane);
		if (time < min) {
			min = time;
		}
	}
	if (unit.get_direction()[cY] < 0) {
		Plane currPlane = yPlanes[1];
		float time = time_to_plane(unit, currPlane);
		if (time < min) {
			min = time;
		}
	}
	if (unit.get_direction()[cZ] >= 0) {
		Plane currPlane = zPlanes[0];
		float time = time_to_plane(unit, currPlane);
		if (time < min) {
			min = time;
		}
	}
	if (unit.get_direction()[cZ] < 0) {
		Plane currPlane = zPlanes[1];
		float time = time_to_plane(unit, currPlane);
		if (time < min) {
			min = time;
		}
	}

	int intersectionTime = unit.calc_intersection_time(min);
	Event event = { 0, unitID, unitID, intersectionTime };
	return event;
}


std::vector<int> Boxes::getUnitsInBox(Unit unit) {
	Box currBox = getBox(unit);
	//vector<int> neighborIDs = m_unit_membership[currBox.positions[cX]][currBox.positions[cY]][currBox.positions[cZ]];
	vector<int> neighborIDs;
	for (int i = 0; i < global_num_units; i++) {
		if (m_unit_membership[currBox.positions[cX]][currBox.positions[cY]][currBox.positions[cZ]][i]) {
			neighborIDs.emplace_back(i);
		}
	}
	return neighborIDs;
}

std::vector<int> Boxes::getUnitsInBox(Box box) {
	vector<int> neighborIDs;
	for (int i = 0; i < m_boxes_per_side[cX]; i++) {
		for (int j = 0; j < m_boxes_per_side[cY]; j++) {
			for (int k = 0; k < m_boxes_per_side[cZ]; k++) {
				if (i == box.positions[cX] && j == box.positions[cY] && k == box.positions[cZ]) {
					for (int a = 0; a < global_num_units; a++) {
						if (m_unit_membership[i][j][k][a]) {
							neighborIDs.emplace_back(a);
						}
					}
				}
			}
		}
	}
	return neighborIDs;
}



Boxes::~Boxes()
{
	
}
