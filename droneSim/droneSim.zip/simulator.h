#ifndef simulator_h
#define simulator_h
#include <ctime>
#include <ratio>
#include <Windows.h>
#include <iostream>
#include <iomanip>
#include <set>
#include <stdlib.h>

class Environment;
class Container;

extern Environment globalEnvironment;
extern Container globalContainer;
extern constexpr int global_num_units = 15;
extern constexpr int cX = 0;
extern constexpr int cY = 1;
extern constexpr int cZ = 2;

extern constexpr int TARGET_FPS = 24;


#endif /* simulator_h */