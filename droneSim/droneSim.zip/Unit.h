
#include "Container.h"
#include "Message.h"
#include "Event.h"
#include <queue>
#include <vector>
#include <unordered_map>
#include <cmath>
#include <limits>

#include <ctime>
#include <ratio>
#include <chrono>


#ifndef Unit_h
#define Unit_h

using std::vector;
using std::queue;
using std::unordered_map;
using std::priority_queue;

extern constexpr float default_radius = 0.5;

class Environment;
class Unit {
private:
	vector<queue<Message>> m_message_boxes;
	vector<unordered_map<int, vector<Message>>> m_sorted_messages;
	//priority_queue<boxEvent, vector<boxEvent>, myComparator> m_box_event_queue;
	//priority_queue<ucEvent, vector<ucEvent>, myUCComparator> m_uc_event_queue;
	
	long long m_time_counter = 0;
	float temp_direction[3];
	int m_msgsReceived;
	float m_color[3];

	//current location of unit
	float m_location[3];

	//inner radius of unit
	float m_radius = default_radius;

	//normalized direction vector
	float m_direction[3];

	//speed of unit
	float m_speed;

	//destination point of unit
	float m_dest[3];

	//unit id
	int m_id;

	//outer radius
	float m_bufferRadius = m_radius*3;

	//length of one side of square container
	int m_containerSize;

	//boolean representing whether or not a unit has a destination point
	bool m_hasDest;


public:
	//create a unit with an int id and the total number of units
	Unit(int);

	Unit();

	inline void normalize_direction() {
		float sum = abs(m_direction[0]) + abs(m_direction[1]) + abs(m_direction[2]);
		m_direction[0] = m_direction[0] / sum;
		m_direction[1] = m_direction[1] / sum;
		m_direction[2] = m_direction[2] / sum;
	}

	inline bool isColliding(Unit secondUnit) {
		float x1, y1, z1, x2, y2, z2, r1, r2;
		x1 = m_location[cX];
		y1 = m_location[cY];
		z1 = m_location[cZ];
		x2 = secondUnit.get_location()[cX];
		y2 = secondUnit.get_location()[cY];
		z2 = secondUnit.get_location()[cZ];

		r1 = m_bufferRadius;
		r2 = secondUnit.get_bufferRadius();

		float left = std::abs((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) + (z1 - z2)*(z1 - z2));
		float right = (r1 + r2) * (r1 + r2);
		
		float distance = this->calc_distance_to_site(x2, y2, z2);

		return std::abs((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)+(z1-z2)*(z1-z2)) < (r1 + r2) * (r1 + r2);
	};

	inline void change_direction(float x, float y, float z) {
		m_direction[cX] = x;
		m_direction[cY] = y;
		m_direction[cZ] = z;
	};


	long long unit_collision(int);

	ucEvent process_unit_event();

	void collision_avoidance(long long, float[3]);

	void process_msg(Message);

	long long calc_intersection_time(float);

	inline int get_num_messages() {
		return m_msgsReceived;
	};

	//deletes color, location, destination, and boundary vectors
	~Unit();

	//updates boundary vector, container size variable
	void init_location();

	//updates location
	void calc_next_location(long long);

	//returns color
	inline float* get_color() {
		return m_color;
	};

	//sets color
	inline void set_color(float red, float green, float blue) {
		m_color[0] = red;
		m_color[1] = green;
		m_color[2] = blue;
	};

	//returns radius
	inline float get_radius() {
		return m_radius;
	};

	//returns direction
	inline float* get_direction() {
		return m_direction;
	};

	//returns (does not update) location
	inline float* get_location() {
		return m_location;
	};

	//updates dest variable, hasDest boolean to true, calls set_direction
	void set_dest(float, float, float);

	//returns destination
	inline float* get_dest() {
		return m_dest;
	};

	inline float get_speed() {
		return m_speed;
	};

	//returns id
	inline int get_id() {
		return m_id;
	};

	//returns bufferRadius
	inline float get_bufferRadius() {
		return m_bufferRadius;
	};

	//returns distance to a given point
	float calc_distance_to_site(float, float, float);

	//rewrites location variable
	inline void set_location(float x, float y, float z) {
		m_location[0] = x;
		m_location[1] = y;
		m_location[2] = z;
	};

	//resets unit properties (still need?)
	void reset();

	//calculates unit-container collision
	void check_container_collision();

	//given two colliding units, enacts collision protocol (currently calculates new velocity for both)
	Event perform_unit_collision(Unit&);

	//generates a new random destination
	void init_dest();

	//sets direction towards destination or in a random direction, then normalizes velocity
	void set_direction();

	//sets unit speed
	inline void set_speed(float speed) {
		m_speed = speed;
	};

	bool send(Message, int);

	inline vector<queue<Message>>* get_message_box() {
		return &m_message_boxes;
	};

	void recv(int);

	//receive(vector<msg> &vector, int tag, int amt)
	//return true when i've gotten right num of messages

	void process(long long);

	inline bool has_dest() {
		return m_hasDest;
	};

};
#endif /* Unit_h */