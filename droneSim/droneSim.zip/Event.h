#include "Geometry.h"

#ifndef Event_h
#define Event_h

struct boxEvent {
	int unitID;
	bool enteringBox;
	Box box;
	long long intersectionTime; //num milliseconds between start of sim and unit-plane intersection
};

struct ucEvent {
	int idA;
	int idB;
	Box box;
	long long intersectionTime;
};

struct Event {
	int tag; //0 if box, 1 if uc, 2 if action
	int idA;
	int idB;
	long long timestamp;
};

class myEventComparator
{
public:
	int operator() (Event& event1,Event& event2)
	{
		return event1.timestamp > event2.timestamp;
	}
};

class myComparator
{
public:
	int operator() (boxEvent& event1, boxEvent& event2)
	{
		return event1.intersectionTime > event2.intersectionTime;
	}
};

class myUCComparator
{
public:
	int operator() (ucEvent& event1, ucEvent& event2)
	{
		return event1.intersectionTime > event2.intersectionTime;
	}
};

#endif /* Event_h */#pragma once
