
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <utility>
#include <functional>
#include <strstream>
#include <boost/variant/get.hpp>
#include <unordered_map>
#include <array>
#include <algorithm>
#include <boost/algorithm/clamp.hpp>

#include "Unit.h"
#include "simulator.h"
#include "Geometry.h"
#include "Event.h"

#ifndef Boxes_h
#define Boxes_h

using std::unordered_map;
using std::vector;

class Environment;
const float box_default_radius = 0.5; //reflect unit's default radius
class Boxes {
private:
	//box dimensions (proportional to default radius)
	int m_box_size[3] = {(int) (box_default_radius * 4), (int)(box_default_radius * 4), (int)(box_default_radius * 4) };
	int containerSize = globalContainer.get_size();
	//number of boxes per side
	int m_boxes_per_side[3] = { containerSize/m_box_size[0],
		containerSize/ m_box_size[1],
		containerSize / m_box_size[2]};
	//nested arrays of planes
	std::array<std::array<Plane, 2>, 3> m_planes[10][10][10]; //obviously, don't use magic numbers
	float m_epsilon = 0.25;
	//4d nested array representing whether not a given unit is in a given box
	bool m_unit_membership[10][10][10][global_num_units]; //MORE magic numbers

public:
	Boxes();

	inline Box getBox(Unit unit) {
		//get from unit location to box indices
		float unitX = unit.get_location()[cX];
		float unitY = unit.get_location()[cY];
		float unitZ = unit.get_location()[cZ];

		//transform location values to index from lower left far corner
		unitX += globalContainer.get_rightX();
		unitY += globalContainer.get_topY();
		unitZ += -(globalContainer.get_farZ());

		int xBoxIndex = unitX / m_box_size[cX];
		int yBoxIndex = unitY / m_box_size[cY];
		int zBoxIndex = unitZ / m_box_size[cZ];

		xBoxIndex = boost::algorithm::clamp(xBoxIndex, 0, m_boxes_per_side[cX]);
		yBoxIndex = boost::algorithm::clamp(yBoxIndex, 0, m_boxes_per_side[cY]);
		zBoxIndex = boost::algorithm::clamp(zBoxIndex, 0, m_boxes_per_side[cZ]);

		Box myBox = { xBoxIndex, yBoxIndex, zBoxIndex };
		m_unit_membership[xBoxIndex][yBoxIndex][zBoxIndex][unit.get_id()] = true;
		return myBox;
	};

	vector<Event> get_collisions(Unit);
	vector<Box> get_future_boxes(Unit);
	std::vector<int> getUnitsInBox(Unit); //returns vector of unit IDs of units in same box(es)
	std::vector<int> getUnitsInBox(Box);
	Event get_next_box_event(Unit);
	float time_to_plane(Unit, Plane);
	void get_plane_info(Plane, myVector&, myVector&);
	~Boxes();
};


#endif /* Boxes_h */