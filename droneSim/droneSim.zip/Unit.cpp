#include "Unit.h"
#include "Container.h"
#include "Message.h"
#include "Environment.h"
#include "simulator.h"
#include <vector>
#include <cmath>
#include <sstream>
#include <string>

#  include <GL/glew.h>
#  include <GL/freeglut.h>

#include <iostream>
#include <utility>
#include <functional>
#include <strstream>
using std::string;


Unit::Unit() {
	
}

Unit::Unit(int i) : m_id{i}
{
	for (int j = 0; j < global_num_units; j++) {
		m_message_boxes.emplace_back();
		m_sorted_messages.emplace_back();
	}	
	m_msgsReceived = 0;
	//initialize particle properties
	m_color[0] = 0;
	m_color[1] = 1;
	m_color[2] = 1;

	m_containerSize = globalContainer.get_size();

	int max = 1000 * (m_containerSize - 2 * m_bufferRadius); //sub out m_radius for m_bufferRadius?

	m_location[0] = (float)(rand() % max) / 1000 - m_containerSize / 2 + m_bufferRadius;
	m_location[1] = (float)(rand() % max) / 1000 - m_containerSize / 2 + m_bufferRadius;
	m_location[2] = (float)(rand() % max) / 1000 - 30 + m_bufferRadius;
	
	m_speed = (float) .0075; //distance traveled per ms
	m_hasDest = false;
	//m_radius = 0.5;// (float);// -m_containerSize / 2; 0.25; //make constexpr default radius
	m_radius = default_radius;
	m_bufferRadius = m_radius * 2;
	init_location();
	set_direction();	
}


Unit::~Unit()
{
	m_message_boxes.clear();
	m_sorted_messages.clear();
}




void Unit::init_location() {
	/*m_containerSize = globalContainer.get_size();

	m_radius;
	m_bufferRadius;
	int max = 1000*(m_containerSize - 2 * (m_radius*3)); //sub out m_radius for m_bufferRadius?

	m_location[0] = 3;// (float)(rand() % max) / 1000 - m_containerSize / 2 + (m_radius * 3);
	m_location[1] = 3;// (float)(rand() % max) / 1000 - m_containerSize / 2 + (m_radius * 3);
	m_location[2] = 3;// (float)(rand() % max) / 1000 - 30 + m_radius * 3;
	//m_last_moved = timer.now();*/
}

void Unit::calc_next_location(long long loop_time) {
	
	float t = loop_time;
	
	m_location[0] = m_location[0] + m_direction[0] * m_speed * t;
	m_location[1] = m_location[1] + m_direction[1] * m_speed * t;
	m_location[2] = m_location[2] + m_direction[2] * m_speed * t;
	

};

long long Unit::calc_intersection_time(float time) {
	return globalEnvironment.get_num_milliseconds() + time;
	
}

void Unit::set_direction() {

	if (m_hasDest) {
		//incorporate location
		m_direction[0] = m_dest[0] - m_location[0];
		m_direction[1] = m_dest[1] - m_location[1];
		m_direction[2] = m_dest[2] - m_location[2];
	}
	else {
		m_direction[0] = ((float)(rand() % 201))-100;
		m_direction[1] = ((float)(rand() % 201))-100;
		m_direction[2] = ((float)(rand() % 201))-100;
	}
	normalize_direction();
}

void Unit::init_dest() {
	//generate new random destination
	m_radius;
	m_bufferRadius;
	
	int max = 1000 * (m_containerSize - 2 * (m_radius * 3)); //sub out m_radius for m_bufferRadius?
	m_dest[0] = (float)(rand() % max) / 1000 - m_containerSize / 2 + (m_radius * 3);
	m_dest[1] = (float)(rand() % max) / 1000 - m_containerSize / 2 + (m_radius * 3);
	m_dest[2] = (float)(rand() % max) / 1000 - 30 + m_radius * 3;

	//set direction
	m_hasDest = true;
	set_direction();

}

void Unit::set_dest(float x_dest, float y_dest, float z_dest) {
	m_dest[0] = x_dest;
	m_dest[1] = y_dest;
	m_dest[2] = z_dest;
	m_hasDest = true;
	set_direction();
}

float Unit::calc_distance_to_site(float site_x, float site_y, float site_z) {
	//get particle location
	float m_x = m_location[0];
	float m_y = m_location[1];
	float m_z = m_location[2];

	//get other location
	float x = (m_x - site_x);
	float y = (m_y - site_y);
	float z = (m_z - site_z);

	//use distance formula
	float distance = sqrt(abs(x*x + y * y + z * z));
	return distance;
}


void Unit::reset() {
	//reset particle properties
	m_color;
	m_color[0] = 0;
	m_color[1] = 0;
	m_color[2] = 1;

	m_location;
	m_location[0] = (float)(rand() % 61) / 10 - 3;
	m_location[1] = (float)(rand() % 61) / 10 - 3;
	m_location[2] = (float)(rand() % 31) / 10 - 13;

	m_radius = (float) 0.075;

}

void Unit::check_container_collision() {
	//get particle location
	float particleX = m_location[0];
	float particleY = m_location[1];
	float particleZ = m_location[2];
	//float sphereRadius = m_radius * 2;
	int leftX = globalContainer.get_leftX();
	int rightX = globalContainer.get_rightX();
	int bottomY = globalContainer.get_bottomY();
	int topY = globalContainer.get_topY();
	int closeZ = globalContainer.get_closeZ();
	int farZ = globalContainer.get_farZ();

	if (particleX - m_bufferRadius <= leftX && m_direction[0] < 0) {
		m_direction[0] = -m_direction[0];
	}

	if (particleX + m_bufferRadius >= rightX && m_direction[0] > 0) {
		m_direction[0] = -m_direction[0];
	}

	if (particleY - m_bufferRadius <= bottomY && m_direction[1] < 0) {
		m_direction[1] = -m_direction[1];
	}

	if (particleY + m_bufferRadius >= topY && m_direction[1] > 0) {
		m_direction[1] = -m_direction[1];
	}

	if (particleZ - m_bufferRadius <= farZ && m_direction[2] < 0) {
		m_direction[2] = -m_direction[2];
	}

	if (particleZ + m_bufferRadius >= closeZ && m_direction[2] > 0) {
		m_direction[2] = -m_direction[2];
	}
}

void Unit::recv(int senderID = -1) {
	//int val = 5;
	//m_message_boxes[0].push(Message(0, 0, 0, &val));
	int num_units = global_num_units;
	if (senderID == -1) {
		senderID = rand() % num_units;
	}
	int currBox = senderID;
	queue<Message> &currQueue = m_message_boxes[currBox];
	int counter = 0;
	//loop through all processes once using for-loop
	while (currQueue.empty()&&counter<num_units) {
		//iterate through boxes
		currBox++;
		currQueue = m_message_boxes[currBox%num_units];
		counter++;
	}
	if (!currQueue.empty()) {
		Message message = currQueue.front();
		//m_msgsReceived++;
		currQueue.pop();
		process_msg(message);
	}
	return;
}

void Unit::process_msg(Message message) {
	//get senderID and tag from message
	int msg_tag = message.get_tag();
	int sender_id = message.get_sender();
	m_sorted_messages[sender_id][msg_tag].emplace_back(message);
	m_msgsReceived++;
}


bool Unit::send(Message message, int recvID) {
	//get reciver unit from id, correct box from unit
	Unit& receiver = globalEnvironment.get_unit(recvID);

	//receiver.write_message(m_id, message);

	vector<queue<Message>>* receiverBox = receiver.get_message_box();
	
	queue<Message> &senderQueue = (*receiverBox)[m_id];
	//receiver.recv(-1);
	//add message to box
	//queue<Message> &senderQueue = *(receiverBox+m_id);
	senderQueue.push(message);
	//receiverBox[m_id].push(message);
	return true;
}


void Unit::process(long long loop_time) {
	//process: update location, receive messages, normalize direction
	normalize_direction();
	calc_next_location(loop_time);
	//if (m_speed < 0.1) {
		//init_dest();
	//}
	recv(-1);

}

long long Unit::unit_collision(int unitID) {
	if (unitID == m_id) {
		return -1;
	}
	Unit unitB = globalEnvironment.get_unit(unitID);
	myVector locationVector = {m_location[cX]-unitB.get_location()[cX],
		m_location[cY] - unitB.get_location()[cY],
		m_location[cZ] - unitB.get_location()[cZ] };
	myVector sumDirectionVector = {m_direction[cX] - unitB.get_direction()[cX],
		m_direction[cY] - unitB.get_direction()[cY],
		m_direction[cZ] - unitB.get_direction()[cZ] };
	double radiusSum = m_bufferRadius + unitB.get_bufferRadius();

	double c = locationVector.dot_product(locationVector) - pow(radiusSum, 2);
	if (c < 0) {
		return -1;
	}

	float a = sumDirectionVector.dot_product(sumDirectionVector);
	float b = sumDirectionVector.dot_product(locationVector);
	if (b >= 0) {
		return -1;
	}
	float d = b * b - a * c;
	if (d < 0) {
		return -1;
	}

	float t = (-b - sqrt(d)) / a;
	return t/m_speed+globalEnvironment.get_num_milliseconds();
		
}


void Unit::collision_avoidance(long long time, float newDir[3]) {
	m_time_counter = time;

	temp_direction[cX] = m_direction[cX];
	temp_direction[cY] = m_direction[cY];
	temp_direction[cZ] = m_direction[cZ];

	m_direction[cX] = newDir[cX];
	m_direction[cY] = newDir[cY];
	m_direction[cZ] = newDir[cZ];
}


Event Unit::perform_unit_collision(Unit &unit) {
	Event event {};
	if (unit.get_id() != m_id) {
		//if (isColliding(unit)) {
			long long time = m_bufferRadius / m_speed; //number of ms to travel buffer radius
			time += globalEnvironment.get_num_milliseconds();
			
			event = { 2, m_id, m_id, time};

			temp_direction[cX] = m_direction[cX];
			temp_direction[cY] = m_direction[cY];
			temp_direction[cZ] = m_direction[cZ];


			if (m_id > unit.get_id()) {
				change_direction(1, 1, 1);
				unit.change_direction(-1, -1, -1);
			}
			else {
				change_direction(-1, -1, -1);
				unit.change_direction(1, 1, 1);
			}
		}
	//}
	return event;
}